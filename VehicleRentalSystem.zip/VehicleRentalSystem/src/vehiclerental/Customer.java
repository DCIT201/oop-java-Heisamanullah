package vehiclerental;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String name;
    private List<RentalTransaction> rentalHistory = new ArrayList<>();

    public Customer(String name) {
        this.name = name;
    }

    public void addRental(RentalTransaction rental) {
        rentalHistory.add(rental);
    }

    public List<RentalTransaction> getRentalHistory() {
        return rentalHistory;
    }

    public boolean isEligibleToRent() {
        return rentalHistory.size() > 5; // Eligibility rule for example
    }
}
