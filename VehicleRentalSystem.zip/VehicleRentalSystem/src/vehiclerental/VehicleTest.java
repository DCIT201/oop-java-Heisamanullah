package vehiclerental;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class VehicleTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
