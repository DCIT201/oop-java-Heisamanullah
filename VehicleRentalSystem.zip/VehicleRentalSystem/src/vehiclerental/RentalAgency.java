package vehiclerental;

import java.util.ArrayList;
import java.util.List;

public class RentalAgency {

    private List<Vehicle> fleet = new ArrayList<>();
    private List<RentalTransaction> transactions = new ArrayList<>();

    public void addVehicleToFleet(Vehicle vehicle) {
        fleet.add(vehicle);
    }

    public void processRental(Customer customer, Vehicle vehicle, int days) {
        if (vehicle.isAvailableForRental()) {
            vehicle.rent(customer, days);
            RentalTransaction transaction = new RentalTransaction(customer, vehicle, days);
            transactions.add(transaction);
        } else {
            throw new IllegalStateException("Vehicle not available for rental.");
        }
    }
}
