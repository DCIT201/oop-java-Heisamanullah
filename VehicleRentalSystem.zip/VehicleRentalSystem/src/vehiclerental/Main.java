package vehiclerental;

public class Main {

    public static void main(String[] args) {
        // Create rental agency
        RentalAgency agency = new RentalAgency();

        // Add vehicles to the fleet
        Vehicle car = new Car("C001", "Toyota Corolla", 50, true);
        Vehicle motorcycle = new Motorcycle("M001", "Harley Davidson", 30, true);
        Vehicle truck = new Truck("T001", "Ford F-150", 80, 2000);

        agency.addVehicleToFleet(car);
        agency.addVehicleToFleet(motorcycle);
        agency.addVehicleToFleet(truck);

        // Create a customer
        Customer customer = new Customer("John Doe");

        // Process rental
        agency.processRental(customer, car, 5); // Rent car for 5 days
        agency.processRental(customer, motorcycle, 3); // Rent motorcycle for 3 days
    }
}
